from flask import Flask, render_template
from data import db_session
from data.users import User
from data.jobs import Jobs


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/mars_explorer.sqlite")
    app.run()


@app.route("/")
def db_table():
    session = db_session.create_session()
    result = list()
    for job in session.query(Jobs).all():
        full = {}
        full['id'] = str(job.id)
        print(full['id'])
        full['job_title'] = job.job
        for i in session.query(User).filter(User.id == job.team_leader):
            leader = i
        full['full_name'] = leader.surname + " " + leader.name
        full['time'] = str(job.work_size) + ' ' + 'hours'
        full['team_ids'] = job.collaborators
        full['is_finished'] = str(job.is_finished)
        result.append(full)
    return render_template('table.html', result=result)


if __name__ == '__main__':
    main()